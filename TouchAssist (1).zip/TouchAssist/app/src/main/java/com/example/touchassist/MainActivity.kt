package com.example.touchassist

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** شاشة الإعدادات: نفس ترتيب Settings ‹ Accessibility ‹ Touch ‹ AssistiveTouch في iOS. */
class MainActivity : Activity() {

    private lateinit var content: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(16), dp(24), dp(16), dp(32))
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.parseColor("#F2F2F7"))
        scroll.addView(content)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun serviceEnabled(): Boolean {
        if (AssistService.instance != null) return true
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return s.contains("$packageName/") && s.contains("AssistService")
    }

    private fun render() {
        content.removeAllViews()
        val gestures = Store.loadGestures(this)
        val enabled = serviceEnabled()

        val title = text("اللمس المساعد", 28f, true)
        content.addView(title)

        // ── تفعيل الخدمة
        if (!enabled) {
            val c = card()
            c.addView(text("⚠️ لازم تفعّل خدمة إمكانية الوصول عشان الزر يشتغل", 15f, true))
            c.addView(
                text(
                    "إعدادات إمكانية الوصول ← التطبيقات المُثبّتة ← اللمس المساعد ← تشغيل.\n" +
                        "لو الخيار رمادي (أندرويد 13+): إعدادات التطبيق ← ⋮ ← السماح بالإعدادات المقيّدة.",
                    13f, false
                )
            )
            c.addView(button("فتح إعدادات إمكانية الوصول") {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            })
            content.addView(c)
        }

        // ── المفتاح الرئيسي
        val mainCard = card()
        val sw = Switch(this)
        sw.text = "اللمس المساعد"
        sw.textSize = 17f
        sw.isEnabled = enabled
        sw.isChecked = Store.buttonEnabled(this)
        sw.setOnCheckedChangeListener { _, checked ->
            Store.setButtonEnabled(this, checked)
            AssistService.instance?.refreshButton()
        }
        mainCard.addView(sw)
        content.addView(mainCard)

        // ── تخصيص القائمة العلوية
        content.addView(header("القائمة العلوية"))
        content.addView(topMenuCard())

        // ── الإجراءات المخصصة
        content.addView(header("إجراءات مخصصة"))
        val actCard = card()
        actCard.addView(actionRow("ضغطة واحدة", "single"))
        actCard.addView(divider())
        actCard.addView(actionRow("ضغطتين", "double"))
        actCard.addView(divider())
        actCard.addView(actionRow("ضغطة مطوّلة", "long"))
        content.addView(actCard)
        content.addView(note("بتحدد إيه اللي يحصل لما تضغط على الزر نفسه من غير ما تفتح القائمة."))

        // ── الإيماءات المخصصة
        content.addView(header("الإيماءات المخصصة"))
        val gCard = card()
        if (gestures.isEmpty()) {
            gCard.addView(text("مفيش إيماءات لسه.", 14f, false))
        }
        for ((i, g) in gestures.withIndex()) {
            if (i > 0) gCard.addView(divider())
            val row = LinearLayout(this)
            row.orientation = LinearLayout.VERTICAL
            row.setPadding(0, dp(8), 0, dp(8))
            row.addView(text(g.name, 16f, true))
            val mode = if (g.placeMode) "اختيار المكان" else "مكان ثابت (ماكرو)"
            val rep = if (g.repeat == 0) "تكرار ∞" else "تكرار ${g.repeat}"
            row.addView(text("${g.strokes.size} لمسة • ${g.totalDuration} ms • $mode • $rep", 12f, false))
            row.setOnClickListener {
                val i2 = Intent(this, GestureEditActivity::class.java)
                i2.putExtra("id", g.id)
                startActivity(i2)
            }
            gCard.addView(row)
        }
        gCard.addView(divider())
        val create = text("إنشاء إيماءة جديدة…", 16f, true)
        create.setTextColor(Color.parseColor("#007AFF"))
        create.setPadding(0, dp(10), 0, dp(10))
        create.setOnClickListener {
            val s = AssistService.instance
            if (s == null) {
                Toast.makeText(this, "فعّل الخدمة الأول", Toast.LENGTH_SHORT).show()
            } else {
                s.startRecording()
                moveTaskToBack(true)
            }
        }
        gCard.addView(create)
        content.addView(gCard)
        content.addView(
            note(
                "للماكرو: سجّل اللمسات (نقر / سحب / ضغط) ثم افتح الإيماءة من القائمة وغيّر (مكان ثابت) + (عدد التكرار) " +
                    "+ (التأخير بين التكرار) + (السرعة)، واربطها بضغطة على الزر. اضغط الزر مرة تانية عشان توقفها."
            )
        )

        // ── شفافية وحجم
        content.addView(header("شفافية الزر وهو ساكن"))
        val look = card()
        look.addView(text("${Store.idleOpacity(this)}%", 14f, false))
        look.addView(seek(15, 100, Store.idleOpacity(this)) {
            Store.setIdleOpacity(this, it)
            AssistService.instance?.refreshButton()
        })
        look.addView(text("حجم الزر", 14f, false))
        look.addView(seek(30, 90, Store.btnSize(this)) {
            Store.setBtnSize(this, it)
            AssistService.instance?.refreshButton()
        })
        content.addView(look)

        // ── صلاحية تعديل إعدادات النظام
        content.addView(header("صلاحيات إضافية"))
        val perm = card()
        val canWrite = Settings.System.canWrite(this)
        perm.addView(text(if (canWrite) "✅ تدوير الشاشة: مسموح" else "⚠️ تدوير الشاشة / قفل التدوير: محتاج صلاحية", 14f, true))
        if (!canWrite) {
            perm.addView(button("السماح بتعديل إعدادات النظام") {
                startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
            })
        }
        content.addView(perm)
    }

    // ───────────── القائمة العلوية ─────────────

    private fun topMenuCard(): View {
        val card = card()
        val menu = Store.topMenu(this)

        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#2C2C2E"))
        bg.cornerRadius = dp(22).toFloat()
        panel.background = bg
        panel.setPadding(dp(8), dp(8), dp(8), dp(8))

        var i = 0
        while (i < menu.size) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER
            for (k in i until minOf(i + 4, menu.size)) {
                val id = menu[k]
                val cell = LinearLayout(this)
                cell.orientation = LinearLayout.VERTICAL
                cell.gravity = Gravity.CENTER
                cell.addView(IconView(this, id), LinearLayout.LayoutParams(dp(40), dp(40)))
                val t = TextView(this)
                t.text = Actions.label(this, id)
                t.textSize = 10f
                t.setTextColor(Color.WHITE)
                t.gravity = Gravity.CENTER
                t.maxLines = 2
                cell.addView(t, LinearLayout.LayoutParams(dp(72), ViewGroup.LayoutParams.WRAP_CONTENT))
                cell.setPadding(0, dp(6), 0, dp(6))
                cell.setOnClickListener { chooseAction { picked ->
                    menu[k] = picked
                    Store.setTopMenu(this, menu)
                    render()
                } }
                row.addView(cell, LinearLayout.LayoutParams(dp(80), ViewGroup.LayoutParams.WRAP_CONTENT))
            }
            panel.addView(row)
            i += 4
        }
        card.addView(panel)

        val ctl = LinearLayout(this)
        ctl.orientation = LinearLayout.HORIZONTAL
        ctl.gravity = Gravity.CENTER
        val minus = button("−") {
            if (menu.size > 1) {
                menu.removeAt(menu.size - 1)
                Store.setTopMenu(this, menu)
                render()
            }
        }
        val plus = button("+") {
            if (menu.size < 8) {
                menu.add("none")
                Store.setTopMenu(this, menu)
                render()
            }
        }
        val cnt = text("  عدد الأيقونات: ${menu.size}  ", 14f, false)
        ctl.addView(minus)
        ctl.addView(cnt)
        ctl.addView(plus)
        card.addView(ctl)
        card.addView(note("اضغط على أي أيقونة عشان تغيّر إجراءها. الحد الأقصى 8 أيقونات."))
        return card
    }

    private fun chooseAction(onPick: (String) -> Unit) {
        val ids = Actions.pickable(this)
        val labels = ids.map { Actions.label(this, it) }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("اختر الإجراء")
            .setItems(labels) { _, which -> onPick(ids[which]) }
            .show()
    }

    private fun actionRow(label: String, trigger: String): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(0, dp(10), 0, dp(10))
        val l = text(label, 16f, false)
        row.addView(l, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val v = text(Actions.label(this, Store.getAction(this, trigger)), 14f, false)
        v.setTextColor(Color.parseColor("#8E8E93"))
        row.addView(v)
        row.setOnClickListener {
            chooseAction { picked ->
                Store.setAction(this, trigger, picked)
                AssistService.instance?.refreshButton()
                render()
            }
        }
        return row
    }

    // ───────────── مكوّنات الواجهة ─────────────

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable()
        bg.setColor(Color.WHITE)
        bg.cornerRadius = dp(12).toFloat()
        c.background = bg
        c.setPadding(dp(14), dp(10), dp(14), dp(10))
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(8)
        c.layoutParams = lp
        return c
    }

    private fun header(t: String): TextView {
        val v = text(t, 13f, false)
        v.setTextColor(Color.parseColor("#6B6B70"))
        v.setPadding(dp(4), dp(18), 0, 0)
        return v
    }

    private fun note(t: String): TextView {
        val v = text(t, 12f, false)
        v.setTextColor(Color.parseColor("#6B6B70"))
        v.setPadding(dp(4), dp(6), dp(4), 0)
        return v
    }

    private fun divider(): View {
        val d = View(this)
        d.setBackgroundColor(Color.parseColor("#E5E5EA"))
        d.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1)
        return d
    }

    private fun text(t: String, size: Float, bold: Boolean): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setTextColor(Color.parseColor("#1C1C1E"))
        if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
        v.setPadding(0, dp(2), 0, dp(2))
        return v
    }

    private fun button(t: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.setOnClickListener { onClick() }
        return b
    }

    private fun seek(min: Int, maxV: Int, value: Int, onChange: (Int) -> Unit): SeekBar {
        val s = SeekBar(this)
        s.max = maxV - min
        s.progress = value - min
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {}
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {
                onChange((sb?.progress ?: 0) + min)
            }
        })
        return s
    }
}
