package com.example.touchassist

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.UUID
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max

// ───────────────────────────── الزر العائم ─────────────────────────────

class AssistButton(ctx: Context) : View(ctx) {

    interface Listener {
        fun onSingle()
        fun onDouble()
        fun onLong()
        fun onPress()
        fun onDrag(dx: Float, dy: Float)
        fun onDragEnd()
    }

    var listener: Listener? = null
    var hasDouble = false

    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val h = Handler(Looper.getMainLooper())
    private var downX = 0f
    private var downY = 0f
    private var moved = false
    private var longFired = false
    private var pendingSingle: Runnable? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    private val longRun = Runnable {
        if (!moved) {
            longFired = true
            listener?.onLong()
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val hh = height.toFloat()
        val cx = w / 2f
        val cy = hh / 2f
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#CC2C2C2E")
        c.drawRoundRect(0f, 0f, w, hh, w * 0.28f, w * 0.28f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = w * 0.05f
        p.color = Color.argb(150, 255, 255, 255)
        c.drawCircle(cx, cy, w * 0.34f, p)
        p.style = Paint.Style.FILL
        p.color = Color.argb(235, 255, 255, 255)
        c.drawCircle(cx, cy, w * 0.24f, p)
        p.color = Color.parseColor("#8E8E93")
        c.drawCircle(cx, cy, w * 0.12f, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX
                downY = e.rawY
                moved = false
                longFired = false
                listener?.onPress()
                h.postDelayed(longRun, ViewConfiguration.getLongPressTimeout().toLong())
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downX
                val dy = e.rawY - downY
                if (!moved && hypot(dx.toDouble(), dy.toDouble()) > slop) {
                    moved = true
                    h.removeCallbacks(longRun)
                }
                if (moved) listener?.onDrag(dx, dy)
            }
            MotionEvent.ACTION_UP -> {
                h.removeCallbacks(longRun)
                if (moved) listener?.onDragEnd() else if (!longFired) handleTap()
            }
            MotionEvent.ACTION_CANCEL -> {
                h.removeCallbacks(longRun)
                if (moved) listener?.onDragEnd()
            }
        }
        return true
    }

    private fun handleTap() {
        if (!hasDouble) {
            listener?.onSingle()
            return
        }
        val pending = pendingSingle
        if (pending != null) {
            h.removeCallbacks(pending)
            pendingSingle = null
            listener?.onDouble()
        } else {
            val r = Runnable {
                pendingSingle = null
                listener?.onSingle()
            }
            pendingSingle = r
            h.postDelayed(r, ViewConfiguration.getDoubleTapTimeout().toLong())
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        h.removeCallbacksAndMessages(null)
    }
}

// ───────────────────────────── شاشة تسجيل الإيماءة ─────────────────────────────

class RecorderView(
    ctx: Context,
    private val sw: Int,
    private val sh: Int,
    private val onSave: (Gesture) -> Unit,
    private val onCancel: () -> Unit
) : FrameLayout(ctx) {

    private class Live(val startOffset: Long) {
        val pts = ArrayList<Pt>()
    }

    private val strokes = ArrayList<Live>()
    private val active = HashMap<Int, Live>()
    private var recStart = -1L
    private var playT = -1f
    private var anim: ValueAnimator? = null
    private val surface = Surface(ctx)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    init {
        setBackgroundColor(Color.argb(45, 0, 0, 0))
        addView(surface, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val bar = LinearLayout(ctx)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.isClickable = true
        val bg = GradientDrawable()
        bg.cornerRadius = dp(22).toFloat()
        bg.setColor(Color.parseColor("#EE1C1C1E"))
        bar.background = bg
        bar.setPadding(dp(6), dp(4), dp(6), dp(4))
        bar.addView(btn("✖ إلغاء") { cancel() })
        bar.addView(btn("🗑 مسح") { clear() })
        bar.addView(btn("▶ تشغيل") { preview() })
        bar.addView(btn("💾 حفظ") { save() })
        val blp = LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        blp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        blp.topMargin = dp(28)
        addView(bar, blp)
    }

    private fun btn(text: String, onClick: () -> Unit): TextView {
        val t = TextView(context)
        t.text = text
        t.setTextColor(Color.WHITE)
        t.textSize = 13f
        t.gravity = Gravity.CENTER
        t.setPadding(dp(12), dp(8), dp(12), dp(8))
        t.setOnClickListener { onClick() }
        return t
    }

    private fun clear() {
        anim?.cancel()
        strokes.clear()
        active.clear()
        recStart = -1L
        playT = -1f
        surface.invalidate()
    }

    private fun cancel() {
        anim?.cancel()
        onCancel()
    }

    private fun preview() {
        if (strokes.isEmpty()) return
        anim?.cancel()
        val total = strokes.maxOf { it.startOffset + it.pts.last().t }.toFloat().coerceAtLeast(100f) + 300f
        val a = ValueAnimator.ofFloat(0f, total)
        a.duration = total.toLong()
        a.interpolator = LinearInterpolator()
        a.addUpdateListener {
            playT = it.animatedValue as Float
            surface.invalidate()
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                playT = -1f
                anim = null
                surface.invalidate()
            }
        })
        anim = a
        a.start()
    }

    private fun save() {
        if (strokes.isEmpty()) {
            Toast.makeText(context, "اعمل لمسة أو سحبة الأول", Toast.LENGTH_SHORT).show()
            return
        }
        anim?.cancel()
        val list = ArrayList<Stroke>()
        for (s in strokes) list.add(Stroke(s.startOffset, normalize(s.pts)))
        onSave(Gesture(UUID.randomUUID().toString(), "", list, sw, sh))
    }

    /** تخفيف النقاط + تحويل اللمسة/الضغطة الثابتة لنقطتين (بداية ونهاية بنفس المكان). */
    private fun normalize(src: List<Pt>): List<Pt> {
        val first = src.first()
        val last = src.last()
        var travel = 0f
        for (i in 1 until src.size) travel += abs(src[i].x - src[i - 1].x) + abs(src[i].y - src[i - 1].y)
        if (travel < 8f) {
            return listOf(first, Pt(first.x, first.y, max(last.t, 40L)))
        }
        val out = ArrayList<Pt>()
        out.add(first)
        var kept = first
        for (i in 1 until src.size - 1) {
            val p = src[i]
            if (abs(p.x - kept.x) + abs(p.y - kept.y) >= 3f) {
                out.add(p)
                kept = p
            }
        }
        out.add(Pt(last.x, last.y, max(last.t, out.last().t + 1)))
        return out
    }

    private inner class Surface(c: Context) : View(c) {
        private val pathPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 8f
            color = Color.argb(210, 10, 132, 255)
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.argb(150, 10, 132, 255)
        }
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 48f
            textAlign = Paint.Align.CENTER
            setShadowLayer(8f, 0f, 0f, Color.BLACK)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (anim != null) return true
            val loc = IntArray(2)
            getLocationOnScreen(loc)
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                    if (strokes.size >= 300) return true
                    if (recStart < 0) recStart = e.eventTime
                    val i = e.actionIndex
                    val s = Live(max(0L, e.eventTime - recStart))
                    s.pts.add(Pt(e.getX(i) + loc[0], e.getY(i) + loc[1], 0L))
                    active[e.getPointerId(i)] = s
                    strokes.add(s)
                }
                MotionEvent.ACTION_MOVE -> {
                    for (i in 0 until e.pointerCount) {
                        val s = active[e.getPointerId(i)] ?: continue
                        for (hh in 0 until e.historySize) {
                            addPt(s, e.getHistoricalX(i, hh) + loc[0], e.getHistoricalY(i, hh) + loc[1], e.getHistoricalEventTime(hh))
                        }
                        addPt(s, e.getX(i) + loc[0], e.getY(i) + loc[1], e.eventTime)
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                    val i = e.actionIndex
                    val s = active.remove(e.getPointerId(i))
                    if (s != null) addPt(s, e.getX(i) + loc[0], e.getY(i) + loc[1], e.eventTime)
                }
                MotionEvent.ACTION_CANCEL -> active.clear()
            }
            invalidate()
            return true
        }

        private fun addPt(s: Live, x: Float, y: Float, time: Long) {
            val t = max(time - recStart - s.startOffset, s.pts.last().t)
            s.pts.add(Pt(x, y, t))
        }

        override fun onDraw(c: Canvas) {
            val loc = IntArray(2)
            getLocationOnScreen(loc)
            if (strokes.isEmpty()) {
                c.drawText("المس الشاشة لتسجيل الإيماءة", width / 2f, height / 2f, textPaint)
            }
            for (s in strokes) {
                val limit = if (playT < 0f) Long.MAX_VALUE else playT.toLong() - s.startOffset
                if (limit < 0) continue
                val path = Path()
                var started = false
                var lx = 0f
                var ly = 0f
                for (p in s.pts) {
                    if (p.t > limit) break
                    val x = p.x - loc[0]
                    val y = p.y - loc[1]
                    if (!started) {
                        path.moveTo(x, y)
                        started = true
                    } else {
                        path.lineTo(x, y)
                    }
                    lx = x
                    ly = y
                }
                if (started) {
                    c.drawPath(path, pathPaint)
                    c.drawCircle(lx, ly, 34f, dotPaint)
                }
            }
        }
    }
}

// ───────────────────────────── شاشة اختيار مكان التنفيذ (زي دواير iOS الزرقا) ─────────────────────────────

class PlaceView(
    ctx: Context,
    private val g: Gesture,
    private val sw: Int,
    private val sh: Int,
    private val onDone: (Float, Float) -> Unit,
    private val onCancel: () -> Unit
) : FrameLayout(ctx) {

    private val sx = sw.toFloat() / g.screenW
    private val sy = sh.toFloat() / g.screenH
    private var cx = 0f
    private var cy = 0f
    private var offX = 0f
    private var offY = 0f

    private val circle = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(170, 10, 132, 255)
    }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 6f
        color = Color.argb(120, 10, 132, 255)
        strokeCap = Paint.Cap.ROUND
    }
    private val hint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 44f
        textAlign = Paint.Align.CENTER
        setShadowLayer(8f, 0f, 0f, Color.BLACK)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    init {
        setWillNotDraw(false)
        setBackgroundColor(Color.argb(60, 0, 0, 0))
        var sumX = 0f
        var sumY = 0f
        for (s in g.strokes) {
            sumX += s.points.first().x * sx
            sumY += s.points.first().y * sy
        }
        val n = max(1, g.strokes.size)
        cx = sumX / n
        cy = sumY / n
        offX = sw / 2f - cx
        offY = sh / 2f - cy

        val cancelBtn = TextView(ctx)
        cancelBtn.text = "✖ إلغاء"
        cancelBtn.setTextColor(Color.WHITE)
        cancelBtn.textSize = 14f
        cancelBtn.setPadding(dp(16), dp(8), dp(16), dp(8))
        val bg = GradientDrawable()
        bg.cornerRadius = dp(20).toFloat()
        bg.setColor(Color.parseColor("#EE1C1C1E"))
        cancelBtn.background = bg
        cancelBtn.setOnClickListener { onCancel() }
        val lp = LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.topMargin = dp(28)
        addView(cancelBtn, lp)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                offX = e.rawX - cx
                offY = e.rawY - cy
                invalidate()
            }
            MotionEvent.ACTION_UP -> onDone(offX, offY)
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        c.drawText("اسحب الدواير للمكان اللي عايزه وارفع إصبعك", width / 2f, height * 0.18f, hint)
        for (s in g.strokes) {
            val path = Path()
            var first = true
            for (p in s.points) {
                val x = p.x * sx + offX - loc[0]
                val y = p.y * sy + offY - loc[1]
                if (first) {
                    path.moveTo(x, y)
                    first = false
                } else {
                    path.lineTo(x, y)
                }
            }
            c.drawPath(path, line)
            val f = s.points.first()
            c.drawCircle(f.x * sx + offX - loc[0], f.y * sy + offY - loc[1], 40f, circle)
        }
    }
}
